import { Link } from "react-router-dom";

const Navbar = () => (
  <nav className="bg-blue-600 p-4">
    <div className="container mx-auto flex justify-between items-center">
      <h1 className="text-white text-xl font-bold">TaskManager</h1>
      <div>
        <Link
          to="/tasks"
          className="text-white hover:text-blue-200 px-3 transition"
        >
          Tasks
        </Link>
        <Link
          to="/tasks/new"
          className="text-white hover:text-blue-200 px-3 transition"
        >
          Create Task
        </Link>
      </div>
    </div>
  </nav>
);

export default Navbar;
