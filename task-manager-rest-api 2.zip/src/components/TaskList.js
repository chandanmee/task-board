import { useEffect, useState } from "react";
import { getTasks, deleteTask } from "../services/api";
import { Link } from "react-router-dom";

const TaskList = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [searchQuery, setSearchQuery] = useState(""); // State for search query

  useEffect(() => {
    getTasks()
      .then((response) => setTasks(response.data))
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = (id) => {
    deleteTask(id).then(() => {
      setTasks(tasks.filter((task) => task.id !== id));
    });
  };


  const handleBulkDelete = () => {
    const promises = selectedTasks.map((id) => deleteTask(id));
    Promise.all(promises).then(() => {
      setTasks(tasks.filter((task) => !selectedTasks.includes(task.id)));
      setSelectedTasks([]);
    });
  };

  const toggleTaskSelection = (id) => {
    setSelectedTasks((prev) =>
      prev.includes(id) ? prev.filter((taskId) => taskId !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedTasks.length === tasks.length) {
      setSelectedTasks([]);
    } else {
      setSelectedTasks(tasks.map((task) => task.id));
    }
  };

 // Filter tasks based on the search query
 const filteredTasks = tasks.filter((task) =>
  task.title.toLowerCase().includes(searchQuery.toLowerCase())
);

  if (loading) return <p className="text-center mt-6">Loading tasks...</p>;
  return (
    <div className="container mx-auto mt-6">
      <h2 className="text-2xl font-bold mb-4">Tasks</h2>

      {/* Search Bar */}
      <div className="mb-4">
        <input
          type="text"
          placeholder="Search tasks..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="border px-4 py-2 rounded-lg w-full"
        />
      </div>

      <div className="mb-4">
        <input
          type="checkbox"
          checked={selectedTasks.length === filteredTasks.length && filteredTasks.length > 0}
          onChange={toggleSelectAll}
        />
        <span className="ml-2">Select All</span>
        <button
          onClick={handleBulkDelete}
          className={`ml-4 px-4 py-1 rounded ${
            selectedTasks.length > 0
              ? "bg-red-500 text-white hover:bg-red-600"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
          disabled={selectedTasks.length === 0}
        >
          Bulk Delete
        </button>
      </div>

      {/* Display filtered tasks */}
      <ul>
        {filteredTasks.map((task) => (
          <li
            key={task.id}
            className="bg-white shadow-md rounded-lg mb-4 p-4 flex justify-between items-center"
          >
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={selectedTasks.includes(task.id)}
                onChange={() => toggleTaskSelection(task.id)}
              />
              <Link
                to={`/tasks/${task.id}`}
                className="ml-2 text-blue-600 font-semibold hover:underline"
              >
                {task.title}
              </Link>
            </div>
            <button
              onClick={() => handleDelete(task.id)}
              className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;