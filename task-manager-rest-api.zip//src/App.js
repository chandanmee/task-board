import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import TaskList from "./components/TaskList";
import TaskDetails from "./components/TaskDetails";
import TaskForm from "./components/TaskForm";
import "./index.css";

const App = () => (
  <Router>
    <Navbar />
    <Routes>
      <Route path="/tasks" element={<TaskList />} />
      <Route path="/tasks/new" element={<TaskForm />} />
      <Route path="/tasks/:id" element={<TaskDetails />} />
      <Route path="/tasks/:id/edit" element={<TaskForm editing />} />
    </Routes>
  </Router>
);

export default App;
