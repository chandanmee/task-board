import { useEffect, useState } from "react";
import { getTasks, deleteTask } from "../services/api";
import { Link } from "react-router-dom";

const TaskList = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getTasks()
      .then((response) => setTasks(response.data))
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = (id) => {
    deleteTask(id).then(() => {
      setTasks(tasks.filter((task) => task.id !== id));
    });
  };

  if (loading) return <p className="text-center mt-6">Loading tasks...</p>;

  return (
    <div className="container mx-auto mt-6">
      <h2 className="text-2xl font-bold mb-4">Tasks</h2>
      <ul>
        {tasks.map((task) => (
          <li
            key={task.id}
            className="bg-white shadow-md rounded-lg mb-4 p-4 flex justify-between items-center"
          >
            <Link
              to={`/tasks/${task.id}`}
              className="text-blue-600 font-semibold hover:underline"
            >
              {task.title}
            </Link>
            <button
              onClick={() => handleDelete(task.id)}
              className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;
